<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE SEE [

<!--   XML DESCRIPTIONS                      -->
<!--   +     Required and repeatable element -->
<!--   ?     Optional element                -->
<!--   *     Optional and repeatable element -->
<!--   ,     elements must follow in this order  -->
<!--   |     "or" connector (pick one element)   -->

<!--       ELEMENT  MIN  CONTENT -->
<!ELEMENT  SEE      (PFILE , NPUNIT,  MFILE, NMUNIT,
                     SRECALL, SPRECISION, LRECALL, LPRECISION,
                     JQ1, JQ2, JQ3, JQ4, JQ5, JQ6, JQ7, JQ8, JQ9, JQ10, JQ11, JQ12,
                     Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11, Q12,
		     JUMPU?,
		     UMPU, MEVALS)> 
<!ATTLIST  SEE      VERSION CDATA #REQUIRED>
<!-- Model Summary File -->
<!ELEMENT  MFILE            (#PCDATA)>
<!-- Number of Model Summary Units -->
<!ELEMENT  NMUNIT           (#PCDATA)>
<!-- Peer Summary File -->
<!ELEMENT  PFILE            (#PCDATA)>
<!-- Number of Peer Summary Units -->
<!ELEMENT  NPUNIT           (#PCDATA)>
<!-- Strict Recall -->
<!ELEMENT  SRECALL          (#PCDATA)>
<!-- Strict Precision -->
<!ELEMENT  SPRECISION       (#PCDATA)>
<!-- Lenient Recall -->
<!ELEMENT  LRECALL          (#PCDATA)>
<!-- Lenient Precision -->
<!ELEMENT  LPRECISION       (#PCDATA)>
<!-- Overall Quality -->
<!ELEMENT  JQ1        (#PCDATA)>
<!ELEMENT  JQ2        (#PCDATA)>
<!ELEMENT  JQ3        (#PCDATA)>
<!ELEMENT  JQ4        (#PCDATA)>
<!ELEMENT  JQ5        (#PCDATA)>
<!ELEMENT  JQ6        (#PCDATA)>
<!ELEMENT  JQ7        (#PCDATA)>
<!ELEMENT  JQ8        (#PCDATA)>
<!ELEMENT  JQ9        (#PCDATA)>
<!ELEMENT  JQ10       (#PCDATA)>
<!ELEMENT  JQ11       (#PCDATA)>
<!ELEMENT  JQ12       (#PCDATA)>
<!ELEMENT  Q1        (#PCDATA)>
<!ELEMENT  Q2        (#PCDATA)>
<!ELEMENT  Q3        (#PCDATA)>
<!ELEMENT  Q4        (#PCDATA)>
<!ELEMENT  Q5        (#PCDATA)>
<!ELEMENT  Q6        (#PCDATA)>
<!ELEMENT  Q7        (#PCDATA)>
<!ELEMENT  Q8        (#PCDATA)>
<!ELEMENT  Q9        (#PCDATA)>
<!ELEMENT  Q10       (#PCDATA)>
<!ELEMENT  Q11       (#PCDATA)>
<!ELEMENT  Q12       (#PCDATA)>
<!-- Unmarked PUs: need not be included but relevant -->
<!ELEMENT  JUMPU    (#PCDATA)>
<!ELEMENT  UMPU    (#PCDATA)>
<!-- Model Unit Evaluation (Per Model Unit) -->
<!ELEMENT  MEVALS           (MSID, MUID, PUIDS,
                             COMPLETENESS)+>
<!-- Model Unit Serial ID -->
<!ELEMENT MSID              (#PCDATA)>
<!-- Model Unit ID -->
<!ELEMENT MUID              (#PCDATA)>
<!-- Peer Unit ID -->
<!ELEMENT PUIDS             (#PCDATA)>
<!ELEMENT COMPLETENESS      (#PCDATA)>

]>
<SEE VERSION="3.0">
<PFILE>/nlpir/duc/duc2002/eval/peer4/D063.M.010.J.C.html</PFILE>
<NPUNIT>1</NPUNIT>
<MFILE>/nlpir/duc/duc2002/eval/models/D063.M.010.J.E.html</MFILE>
<NMUNIT>1</NMUNIT>
<SRECALL>0.000</SRECALL>
<SPRECISION>0.000</SPRECISION>
<LRECALL>1.000</LRECALL>
<LPRECISION>1.000</LPRECISION>
<JQ1>0</JQ1>
<JQ2>0</JQ2>
<JQ3>0</JQ3>
<JQ4>0</JQ4>
<JQ5>0</JQ5>
<JQ6>0</JQ6>
<JQ7>0</JQ7>
<JQ8>0</JQ8>
<JQ9>0</JQ9>
<JQ10>0</JQ10>
<JQ11>0</JQ11>
<JQ12>0</JQ12>
<Q1>0</Q1>
<Q2>0</Q2>
<Q3>0</Q3>
<Q4>0</Q4>
<Q5>0</Q5>
<Q6>0</Q6>
<Q7>0</Q7>
<Q8>0</Q8>
<Q9>0</Q9>
<Q10>0</Q10>
<Q11>0</Q11>
<Q12>0</Q12>
<UMPU>0</UMPU>
<MEVALS>
<MSID>1</MSID>
<MUID>1</MUID>
<PUIDS>1</PUIDS>
<COMPLETENESS>80</COMPLETENESS>
</MEVALS>
</SEE>
